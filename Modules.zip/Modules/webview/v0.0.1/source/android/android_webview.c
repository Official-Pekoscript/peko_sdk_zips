#include <jni.h>

JNIEnv *env;
jobject main_obj;

void webview_navigate(const char* url) {
    jclass main_class = (*env).GetObjectClass(main_obj);

    // get the method IDs from that class
    jmethodID method_id_navigate = (*env).GetMethodID(main_class, "navigate", "(Ljava/lang/String;)V");

    // then call them.
    (*env).CallVoidMethod(main_obj, method_id_navigate, (*env).NewStringUTF(url));
}

void webview_set_html(const char* html) {
    jclass main_class = (*env).GetObjectClass(main_obj);

    // get the method IDs from that class
    jmethodID method_id_set_html = (*env).GetMethodID(main_class, "set_html", "(Ljava/lang/String;)V");

    // then call them.
    (*env).CallVoidMethod(main_obj, method_id_set_html, (*env).NewStringUTF(html));
}

extern "C" {
    void pekomain();
    
    JNIEXPORT void JNICALL Java_com_example_webviewtest_MainActivity_peko_initialize(
            JNIEnv *e,
            jobject mo) {

        env = e;
        main_obj = mo;

        pekomain();
    }
}