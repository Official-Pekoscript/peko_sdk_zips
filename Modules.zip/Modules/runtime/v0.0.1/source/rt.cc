#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

extern "C" {
void* gc_alloc(int size);

char *runtime_string_remove(char *str, int index) {
  char *newstr = (char*)gc_alloc((int)(sizeof(char) * strlen(str) + 1));
  strcpy(newstr, str);
  newstr[strlen(str)] = '\0';

  memmove(&newstr[index], &newstr[index + 1], strlen(newstr) - index);

  return newstr;
}

char *runtime_string_insert(char *destination, char *seed, int pos) {
  char* strC = (char*)gc_alloc((int)(strlen(destination)+strlen(seed)+1));
  strncpy(strC,destination,pos);
  strC[pos] = '\0';
  strcat(strC,seed);
  strcat(strC,destination+pos);
  strcpy(destination,strC);

  return strC;
}

char *runtime_concat_strings(char *str1, char *str2) {
  char *str3 = (char*)gc_alloc((int)(strlen(str1) + strlen(str2) + 1));
  strcpy(str3, str1);
  strcat(str3, str2);

  return str3;
}

bool runtime_string_is_bool(char* str) {
  return !strcmp(str, "true") || !strcmp(str, "false");
}

bool is_digit(char ch) {
  return (ch >= '0' && ch <= '9');
}

bool is_alpha(char ch) {
  return (ch >= 'a' && ch <= 'z')||(ch >= 'A' && ch <= 'Z');
}

bool is_alnum(char ch) {
  return is_digit(ch) || is_alpha(ch);
}

bool runtime_string_is_float(char* str) {
  int index = 0;
  int length = strlen(str);
  bool found_decimal = false;

  while(index < length) {
    if(str[index] == '.') {
      if(found_decimal) {
        return false;
      }

      found_decimal = true;
    }

    if(!is_digit(str[index])) {
      return false;
    }

    index += 1;
  }

  return true;
}

bool runtime_string_is_int(char* str) {
  int index = 0;
  int length = strlen(str);

  while(index < length) {
    if(!is_digit(str[index])) {
      return false;
    }

    index += 1;
  }

  return true;
}

bool runtime_string_is_char(char* str) {
  int length = strlen(str);
  return length == 1;
}

bool runtime_string_to_bool(char* str) {
  return !strcmp(str, "true");
}

float runtime_string_to_float(char* str) {
  return strtof(str, NULL);
}

int runtime_string_to_int(char* str) {
  return atoll(str);
}

char runtime_string_to_char(char* str) {
  return str[0];
}

char* runtime_bool_to_string(bool boolean) {
  if(boolean) {
    return "true";
  } else {
    return "false";
  }
}

int get_number_length(float number) {
  bool number_negative = (number < 0);
  bool number_is_decimal = (number != (float)((int)number));
  float number_without_decimal = fabs(number);
  
  while(number_without_decimal != (float)((int)number_without_decimal)) {
    number_without_decimal *= 10;
  }

  int final_number = (int)number_without_decimal;
  int length = number_is_decimal+number_negative+(number==0);

  while(final_number > 0) {
    final_number /= 10;
    length += 1;
  }

  return length;
}

char* runtime_float_to_string(float number) {
  int number_length = get_number_length(number);
  char* string = (char*)gc_alloc((int)(sizeof(char)*(number_length+1)));
  sprintf(string, "%g", number);

  string[number_length] = '\0';

  return string;
}

char* runtime_int_to_string(int number) {
  int number_length = get_number_length((float)number);
  char* string = (char*)gc_alloc((int)(sizeof(char)*(number_length+1)));
  sprintf(string, "%d", number);
  
  string[number_length] = '\0';

  return string;
}

char* runtime_char_to_string(char ch) {
  char* string = (char*)gc_alloc(sizeof(char)*2);
  string[0] = ch;
  string[1] = '\0';

  return string;
}
}

#ifdef _WIN32
#include <windows.h>

extern "C" {
void windows_hide_console() {
  HWND console_window = GetConsoleWindow(); //window handle
  ShowWindow(console_window, 0)
}
}
#endif